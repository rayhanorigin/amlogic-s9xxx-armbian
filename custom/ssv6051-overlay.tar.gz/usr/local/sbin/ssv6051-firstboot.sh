#!/bin/bash
# Build + install ssv6051 via DKMS for the running kernel, then load it.
exec >>/var/log/ssv6051-firstboot.log 2>&1
echo "=== $(date) kernel $(uname -r) ==="
K=$(uname -r)
if [ ! -e "/lib/modules/$K/build" ]; then
    echo "Kernel headers missing for $K"; exit 1
fi
dkms status -m ssv6051 -v 1.0 | grep -q . || dkms add -m ssv6051 -v 1.0
dkms build   -m ssv6051 -v 1.0 -k "$K" || exit 1
dkms install -m ssv6051 -v 1.0 -k "$K" --force || exit 1
depmod -a "$K"
modprobe ssv6051
systemctl disable ssv6051-firstboot.service
echo done
